package com.example.gabrielnunes.carona;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;

public class cadastro_carona extends AppCompatActivity {

    private EditText data,hora,origem,destino,vagas,valor;
    private Button cadastrar;
    private RequestQueue requestQueue;
    private static final String HttpsURLConnection = "https://kdcarona.16mb.com/bd/carona_controller.php";
    private StringRequest request;


    private String parametros;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_carona);

        data = (EditText) findViewById(R.id.data);
        hora = (EditText) findViewById(R.id.hora);
        origem = (EditText) findViewById(R.id.origem);
        destino = (EditText) findViewById(R.id.destino);
        vagas = (EditText) findViewById(R.id.vagas);
        valor = (EditText) findViewById(R.id.valor);
        cadastrar = (Button) findViewById(R.id.cadastro_confirma);





    }
    private class SolicitaDados extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... urls) {

            return Conexao.postDados(urls[0], parametros);



        }


        @Override
        protected void onPostExecute(String result) {
            Toast.makeText(getApplicationContext(), "Cadastro realizado", Toast.LENGTH_LONG).show();



        }
    }
}