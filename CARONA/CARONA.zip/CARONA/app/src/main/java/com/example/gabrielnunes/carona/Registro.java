package com.example.gabrielnunes.carona;


import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Registro extends AppCompatActivity {


    final Context context = this;
    EditText nome, telefone, email, senha, confirmaSenha;
    CheckBox termos;
    TextView txttermos;
    Button cadastrar;

    String url = "";
    String parametros = "";
/*
    public void mensagem() {
        if (flag == 3) {
            Toast.makeText(context, "Usuário cadastrado com sucesso", Toast.LENGTH_SHORT).show();
        } else if (flag == 2) {
            Toast.makeText(context, "Senhas digitadas não são iguais, favor conferir", Toast.LENGTH_SHORT).show();
        } else if (flag == 1) {
            Toast.makeText(context, "Por favor, Aceite os termos", Toast.LENGTH_SHORT).show();
        } else if (flag == 0) {
            Toast.makeText(context, "Email inválido", Toast.LENGTH_SHORT).show();
        } else if (flag == 4) {
            Toast.makeText(context, "Por favor preencha todos os campos", Toast.LENGTH_SHORT).show();
        }
    }


    public static boolean isEmailValid(String email) {
        boolean isValid = false;

        String expression = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
        CharSequence inputStr = email;

        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(inputStr);
        if (matcher.matches()) {
            isValid = true;
        }
        return isValid;
    }
*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);


        termos = (CheckBox) findViewById(R.id.termos);
        txttermos = (TextView) findViewById(R.id.txttermos);
        cadastrar = (Button) findViewById(R.id.cadastrar);

    cadastrar.setOnClickListener(new View.OnClickListener() {

        @Override
        public void onClick(View view) {
        TextView nome = (TextView) findViewById(R.id.nome);
        TextView telefone = (TextView) findViewById(R.id.telefone);
        TextView email = (TextView) findViewById(R.id.email);
        TextView senha = (TextView) findViewById(R.id.senha);
        TextView confirmaSenha = (TextView) findViewById(R.id.confirmaSenha);


        String nome1=nome.getText().toString();
        String telefone1=telefone.getText().toString();
        String email1=email.getText().toString();
        String senha1=senha.getText().toString();


        ConnectivityManager connMgr = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            url = "http://kdcarona.16mb.com/cadastro2.php";
            parametros = "nome="+nome1+"&telefone="+telefone1+"&email="+email1+"&senha="+senha1;
            new Registro.SolicitaDados().execute(url);

          }
        }
});



    }

    private class SolicitaDados extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... urls) {

            return Conexao.postDados(urls[0], parametros);

        }

        @Override
        protected void onPostExecute(String result) {

            Toast.makeText(getApplicationContext(), result.toString(), Toast.LENGTH_LONG).show();



        }
    }


}